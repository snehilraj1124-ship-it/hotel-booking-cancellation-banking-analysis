import pandas as pd

df = pd.read_csv("hotel_booking_cancellation_dataset.csv")

print("Hotel Booking & Banking Analytics")
print("=" * 40)
print("Rows:", len(df))
print("Cancellation rate: {:.2f}%".format(df["Cancelled"].mean() * 100))

print("\nCancellation by hotel:")
print((df.groupby("Hotel")["Cancelled"].mean() * 100).round(2))

print("\nTransaction value by payment method:")
print(df.groupby("Payment_Method")["Transaction_Amount"].sum().round(2).sort_values(ascending=False))

print("\nRefund value by payment method:")
print(df.groupby("Payment_Method")["Refund_Amount"].sum().round(2).sort_values(ascending=False))
