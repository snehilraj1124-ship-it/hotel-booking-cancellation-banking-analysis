-- Hotel Booking + Banking Analytics
-- Example SQL queries for a relational version of the dataset.

SELECT Hotel,
       COUNT(*) AS bookings,
       AVG(Cancelled) * 100 AS cancellation_rate
FROM hotel_bookings
GROUP BY Hotel;

SELECT Payment_Method,
       COUNT(*) AS transactions,
       SUM(Transaction_Amount) AS total_transaction_value,
       SUM(Refund_Amount) AS total_refund_value
FROM hotel_bookings
GROUP BY Payment_Method
ORDER BY total_transaction_value DESC;

SELECT Market_Segment,
       AVG(Average_Daily_Rate) AS avg_adr,
       AVG(Cancelled) * 100 AS cancellation_rate
FROM hotel_bookings
GROUP BY Market_Segment;
