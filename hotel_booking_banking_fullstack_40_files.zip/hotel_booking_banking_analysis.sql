-- Hotel Booking Cancellation + Banking Analytics
-- SQL analysis for a relational version of the project dataset.

-- 1. Overall cancellation rate
SELECT
    COUNT(*) AS total_bookings,
    SUM(CASE WHEN Cancelled = 1 THEN 1 ELSE 0 END) AS cancelled_bookings,
    ROUND(100.0 * SUM(CASE WHEN Cancelled = 1 THEN 1 ELSE 0 END) / COUNT(*), 2) AS cancellation_rate
FROM hotel_bookings;

-- 2. Cancellation by hotel
SELECT
    Hotel,
    COUNT(*) AS bookings,
    ROUND(100.0 * AVG(Cancelled), 2) AS cancellation_rate,
    ROUND(AVG(Average_Daily_Rate), 2) AS avg_adr
FROM hotel_bookings
GROUP BY Hotel;

-- 3. Cancellation by market segment
SELECT
    Market_Segment,
    COUNT(*) AS bookings,
    ROUND(100.0 * AVG(Cancelled), 2) AS cancellation_rate
FROM hotel_bookings
GROUP BY Market_Segment
ORDER BY cancellation_rate DESC;

-- 4. Payment-method analysis
SELECT
    Payment_Method,
    COUNT(*) AS transactions,
    ROUND(SUM(Transaction_Amount), 2) AS total_transaction_value,
    ROUND(SUM(Refund_Amount), 2) AS total_refund_value,
    ROUND(SUM(Net_Transaction_Value), 2) AS net_transaction_value
FROM hotel_bookings
GROUP BY Payment_Method
ORDER BY total_transaction_value DESC;

-- 5. Payment status analysis
SELECT
    Payment_Status,
    COUNT(*) AS transactions,
    ROUND(SUM(Transaction_Amount), 2) AS transaction_value,
    ROUND(SUM(Refund_Amount), 2) AS refund_value
FROM hotel_bookings
GROUP BY Payment_Status;

-- 6. Payment-risk monitoring
SELECT
    Payment_Risk_Flag,
    COUNT(*) AS transactions,
    ROUND(SUM(Transaction_Amount), 2) AS transaction_value,
    ROUND(SUM(Refund_Amount), 2) AS refund_value
FROM hotel_bookings
GROUP BY Payment_Risk_Flag
ORDER BY transaction_value DESC;

-- 7. Booking value by hotel
SELECT
    Hotel,
    ROUND(AVG(Estimated_Booking_Value), 2) AS avg_booking_value,
    ROUND(SUM(Estimated_Booking_Value), 2) AS total_booking_value
FROM hotel_bookings
GROUP BY Hotel;

-- 8. Lead-time cancellation analysis
SELECT
    CASE
        WHEN Lead_Time_Days <= 30 THEN '0-30'
        WHEN Lead_Time_Days <= 60 THEN '31-60'
        WHEN Lead_Time_Days <= 120 THEN '61-120'
        WHEN Lead_Time_Days <= 240 THEN '121-240'
        ELSE '241-500'
    END AS lead_time_band,
    COUNT(*) AS bookings,
    ROUND(100.0 * AVG(Cancelled), 2) AS cancellation_rate
FROM hotel_bookings
GROUP BY lead_time_band
ORDER BY cancellation_rate DESC;
