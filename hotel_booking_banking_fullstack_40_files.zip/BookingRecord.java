public class BookingRecord {
    private final String bookingId;
    private final String hotel;
    private final int leadTime;
    private final int cancelled;

    public BookingRecord(String bookingId, String hotel, int leadTime, int cancelled) {
        this.bookingId = bookingId;
        this.hotel = hotel;
        this.leadTime = leadTime;
        this.cancelled = cancelled;
    }

    public String getBookingId() { return bookingId; }
    public String getHotel() { return hotel; }
    public int getLeadTime() { return leadTime; }
    public int getCancelled() { return cancelled; }
}
