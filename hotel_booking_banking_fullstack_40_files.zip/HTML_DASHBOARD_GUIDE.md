# HTML Dashboard

Open `dashboard.html` in any modern web browser.

## Dashboard Sections

- Booking KPIs
- Hospitality analytics
- Cancellation analysis
- Banking and payment analytics
- Technology stack

The HTML dashboard is a presentation layer for the SQL and Excel analysis in this project.

## Technologies

- HTML5
- CSS3
- SQL
- Microsoft Excel

No Python is required.
