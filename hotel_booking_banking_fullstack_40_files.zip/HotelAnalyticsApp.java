public class HotelAnalyticsApp {
    public static void main(String[] args) {
        System.out.println("Hotel & Banking Analytics Java Application");
        System.out.println("Run HotelBookingAnalytics or PaymentAnalytics for CSV analysis.");
    }
}
