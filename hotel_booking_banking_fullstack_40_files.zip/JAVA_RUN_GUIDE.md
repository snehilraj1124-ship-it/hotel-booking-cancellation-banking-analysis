# Java Analytics

Compile:

```bash
javac HotelBookingAnalytics.java
javac PaymentAnalytics.java
```

Run:

```bash
java HotelBookingAnalytics
java PaymentAnalytics
```

The Java examples provide a lightweight command-line analytics layer over the CSV dataset.
