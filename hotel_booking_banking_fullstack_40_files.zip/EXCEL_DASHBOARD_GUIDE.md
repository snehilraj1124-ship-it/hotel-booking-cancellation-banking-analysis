# Excel Dashboard Guide

## KPI Cards
- Total Bookings
- Cancellation Rate
- Total Transaction Value
- Total Refund Value
- Net Transaction Value
- Average Daily Rate

## Charts
1. Cancellation Rate by Hotel
2. Cancellation Rate by Lead Time
3. Cancellation Rate by Market Segment
4. Transaction Value by Payment Method
5. Refund Value by Payment Method
6. Payment Risk Flag Distribution
7. Average Booking Value by Hotel

## Suggested Filters
- Hotel
- Arrival Month
- Market Segment
- Customer Type
- Payment Method
- Payment Status

All figures are based on synthetic portfolio data.
