import pandas as pd

df = pd.read_csv("hotel_booking_cancellation_dataset.csv")

summary = {
    "total_bookings": len(df),
    "cancellation_rate_pct": round(df["Cancelled"].mean() * 100, 2),
    "total_transaction_value": round(df["Transaction_Amount"].sum(), 2),
    "total_refund_value": round(df["Refund_Amount"].sum(), 2),
    "net_transaction_value": round(df["Net_Transaction_Value"].sum(), 2)
}

for key, value in summary.items():
    print(f"{key}: {value}")
