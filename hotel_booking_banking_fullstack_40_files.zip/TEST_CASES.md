# Test Cases

| Test | Expected Result |
|---|---|
| CSV exists | Dataset loads successfully |
| Booking IDs unique | No duplicate IDs |
| Transaction amount non-negative | No negative values |
| Refund amount non-negative | No negative values |
| Cancellation is 0/1 | Only valid flags |
| Payment method populated | No blank method |
| HTML opens | Dashboard renders |
| Java compiles | `.class` files generated |
| Python scripts import | No syntax errors |
| SQL file readable | Queries available for execution |
