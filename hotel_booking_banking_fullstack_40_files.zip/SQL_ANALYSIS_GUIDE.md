# SQL Analysis Guide

This project uses **SQL + Excel** instead of Python.

## SQL
Import `hotel_booking_cancellation_dataset.csv` into a SQL database as `hotel_bookings`, then run `hotel_booking_banking_analysis.sql`.

The queries cover:
- cancellation rate
- hotel performance
- market segments
- lead-time analysis
- payment methods
- transaction value
- refunds
- payment status
- payment risk flags
- booking value

## Excel
The workbook `hotel_booking_cancellation_analysis.xlsx` contains the raw data and pre-built summary sheets.

Recommended Excel workflow:
1. Load the `Booking Data` sheet.
2. Convert the range into an Excel Table.
3. Create PivotTables for hotel, segment, customer type and payment method.
4. Create PivotCharts for cancellation rate, transaction value and refunds.
5. Use slicers for Hotel, Market Segment, Payment Method and Payment Status.
6. Build a one-page dashboard.

## Tools
- Microsoft Excel
- SQL
- PivotTables
- PivotCharts
- Data Analysis
- Business Analytics
- Financial/Payment Analytics

## HTML Presentation
Open `dashboard.html` to view a browser-based summary of the project.
