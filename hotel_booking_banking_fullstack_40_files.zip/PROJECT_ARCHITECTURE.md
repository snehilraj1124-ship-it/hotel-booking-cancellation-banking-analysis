# Project Architecture

## Data Layer
CSV dataset containing synthetic hotel booking and payment fields.

## Analysis Layer
- SQL queries
- Excel summaries
- Python analytics scripts
- Java command-line analytics

## Presentation Layer
- HTML5 dashboard
- CSS3 styling
- JavaScript filters

## Goal
Demonstrate a multi-technology business analytics workflow without relying on a single programming language.
