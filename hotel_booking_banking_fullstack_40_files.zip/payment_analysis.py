import pandas as pd

df = pd.read_csv("hotel_booking_cancellation_dataset.csv")

summary = df.groupby("Payment_Method").agg(
    transactions=("Booking_ID", "count"),
    transaction_value=("Transaction_Amount", "sum"),
    refund_value=("Refund_Amount", "sum"),
    net_value=("Net_Transaction_Value", "sum")
).round(2)

print(summary)
summary.to_csv("payment_method_summary.csv")
