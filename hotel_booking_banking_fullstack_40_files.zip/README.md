# Hotel Booking Cancellation Analysis

## 📊 Project Overview

This project analyzes **3,000 synthetic hotel bookings** to understand cancellation patterns and the factors associated with booking cancellations.

The analysis examines hotel type, lead time, deposit type, market segment, customer type, arrival month, average daily rate and estimated booking value.

> **Disclaimer:** This project uses synthetic data created for educational and portfolio purposes. It does not represent any real hotel, customer or booking data.

## 🎯 Objectives

- Calculate the overall cancellation rate
- Compare cancellation rates across hotel types
- Analyze the effect of booking lead time
- Compare deposit types
- Analyze market segments
- Study customer-type behavior
- Explore arrival-month patterns
- Analyze ADR and estimated booking value
- Create hospitality analytics visualizations
- Generate business-oriented insights

## 🗂️ Dataset

The dataset contains **3,000 synthetic hotel booking records**.

### Features

| Feature | Description |
|---|---|
| Booking_ID | Unique booking identifier |
| Hotel | City Hotel or Resort Hotel |
| Lead_Time_Days | Days between booking and arrival |
| Arrival_Month | Expected arrival month |
| Average_Daily_Rate | Average daily room rate |
| Adults | Number of adults |
| Children | Number of children |
| Stay_Length_Nights | Number of nights |
| Booking_Changes | Number of booking changes |
| Special_Requests | Number of special requests |
| Previous_Cancellations | Previous cancellations |
| Previous_Bookings | Previous completed bookings |
| Deposit_Type | Deposit arrangement |
| Market_Segment | Booking market segment |
| Customer_Type | Customer classification |
| Meal_Plan | Meal plan selected |
| Cancelled | Cancellation flag |
| Cancellation_Status | Cancelled or Not Cancelled |
| Estimated_Booking_Value | Synthetic estimated booking value |

## 🛠️ Technologies Used

- HTML5
- CSS3
- SQL
- Microsoft Excel
- PivotTables
- PivotCharts

- Python
- Pandas
- NumPy
- Matplotlib
- Microsoft Excel
- OpenPyXL
- Exploratory Data Analysis
- Hospitality Analytics
- Data Visualization
- Business Analytics

## 🔍 Analysis Performed

### 1. Cancellation Analysis

Calculated the overall distribution of cancelled and non-cancelled bookings.

### 2. Hotel Type Analysis

Compared cancellation rates between City Hotels and Resort Hotels.

### 3. Lead Time Analysis

Grouped bookings by lead-time bands to examine cancellation patterns.

### 4. Deposit Analysis

Compared cancellation behavior across different deposit types.

### 5. Market Segment Analysis

Analyzed cancellation rates across:

- Online TA
- Offline TA/TO
- Direct
- Corporate
- Groups

### 6. Customer Type Analysis

Compared booking behavior and cancellation patterns across customer categories.

### 7. Revenue Analysis

Analyzed average daily rate and estimated booking value alongside cancellation behavior.

## 📈 Visualizations

### Cancellation Distribution
![Cancellation Distribution](01_cancellation_distribution.png)

### Cancellation Rate by Hotel
![Cancellation by Hotel](02_cancellation_by_hotel.png)

### Cancellation Rate by Lead Time
![Cancellation by Lead Time](03_cancellation_by_lead_time.png)

### Cancellation Rate by Deposit Type
![Cancellation by Deposit](04_cancellation_by_deposit.png)

### Cancellation Rate by Market Segment
![Cancellation by Market Segment](05_cancellation_by_market_segment.png)

### Lead Time vs ADR
![Lead Time vs ADR](06_lead_time_vs_adr.png)

## 💡 Key Business Insights

1. Lead time can be used as an important segmentation variable for booking cancellation analysis.

2. Deposit type can provide useful information when studying cancellation behavior.

3. Market segment analysis helps identify differences in booking patterns across customer acquisition channels.

4. Hotels can combine cancellation risk with booking value to support revenue planning.

5. Monitoring cancellation patterns can help improve room inventory and demand-management decisions.

## 📊 Excel Workbook

`hotel_booking_cancellation_analysis.xlsx` contains:

- Booking Data
- By Hotel
- By Lead Time
- By Deposit
- By Segment
- By Customer Type
- By Arrival Month

## ▶️ How to Use

### SQL
Import `hotel_booking_cancellation_dataset.csv` into a SQL database as `hotel_bookings` and run:

```sql
hotel_booking_banking_analysis.sql
```

### Excel
Open:

```text
hotel_booking_cancellation_analysis.xlsx
```

Use PivotTables and PivotCharts to explore cancellations, revenue, payment transactions, refunds and risk flags.

## 📁 Project Structure

```text
hotel-booking-cancellation-analysis/
│
├── hotel_booking_cancellation_dataset.csv
├── hotel_booking_banking_analysis.sql
├── hotel_booking_cancellation_analysis.xlsx
├── 01_cancellation_distribution.png
├── 02_cancellation_by_hotel.png
├── 03_cancellation_by_lead_time.png
├── 04_cancellation_by_deposit.png
├── 05_cancellation_by_market_segment.png
├── 06_lead_time_vs_adr.png
├── analysis_report.md
└── README.md
```


## 🏦 Banking & Payment Analytics

To extend the hospitality analysis into financial analytics, the project also includes a synthetic payment-analysis layer.

### Payment Variables

- Payment Method
- Payment Status
- Transaction Amount
- Refund Amount
- Net Transaction Value
- Payment Risk Flag

### Payment Methods

- Credit Card
- Debit Card
- Net Banking
- UPI
- Bank Transfer

### Financial Analysis

The project analyzes:

- Transaction volume by payment method
- Total transaction value
- Refund value
- Net transaction value
- Payment status distribution
- Payment-risk flags
- Cancelled bookings with paid transactions
- Pending and refunded transactions

This adds a **banking/financial analytics component** to the hotel-booking project and demonstrates how operational data can be connected with payment and transaction analysis.

### New Excel Sheets

- `Banking - Payment Method`
- `Banking - Payment Status`
- `Banking - Risk Flags`

## 📚 Skills Demonstrated

- SQL
- Microsoft Excel
- PivotTables
- Data Analysis
- Exploratory Data Analysis
- Hospitality Analytics
- Revenue Analytics
- Data Visualization
- Excel
- Business Analytics
- Data Storytelling

## 💼 Potential Business Applications

This analysis framework can support:

- Hotel revenue management
- Booking-risk monitoring
- Customer segmentation
- Cancellation analysis
- Inventory planning
- Pricing analysis
- Hospitality dashboards
- Demand forecasting workflows

## ⚠️ Disclaimer

The dataset and metrics in this project are synthetic and intended only for educational and portfolio purposes. They must not be represented as actual hotel or customer statistics.

## 👤 Author

**Snehil Raj**

B.Tech Electrical & Electronics Engineering

Interested in Data Analytics, Business Analytics and Management.


## 🗃️ SQL Analysis

The project includes SQL queries for:

- Overall cancellation rate
- Hotel-level cancellation analysis
- Market-segment analysis
- Lead-time analysis
- Payment-method transaction value
- Refund analysis
- Payment-status analysis
- Payment-risk monitoring
- Booking-value analysis

## 📊 Excel Dashboard Workflow

The Excel workbook can be used to build an interactive dashboard with:

- Cancellation Rate
- Total Bookings
- Total Transaction Value
- Total Refund Value
- Net Transaction Value
- Average Daily Rate
- Booking Value
- Payment Risk Flags

Recommended Excel features: **PivotTables, PivotCharts, slicers and conditional formatting**.


## 🌐 HTML Dashboard

The project also includes a browser-based dashboard:

```text
dashboard.html
```

Open the file in a web browser to view a clean summary of the hospitality and banking analytics.

The HTML layer provides a portfolio-friendly presentation interface, while SQL handles analytical queries and Excel handles structured reporting and dashboard workflows.


## 💻 Programming Languages

### Python
Used for data-quality checks, payment summaries and KPI generation.

### Java
Used for CSV processing, payment analytics and object-oriented application examples.

### Web
HTML5, CSS3 and JavaScript provide the browser dashboard.

### Data & Reporting
SQL and Microsoft Excel provide analytical queries and business reporting.
