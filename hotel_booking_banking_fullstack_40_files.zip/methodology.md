# Methodology

## Data Preparation
The project uses a synthetic dataset of 3,000 hotel bookings. Variables cover booking behavior, hotel attributes, revenue indicators and a synthetic payment layer.

## Analysis
1. Calculate booking and cancellation distributions.
2. Segment cancellations by hotel, lead time, deposit, market segment, customer type and arrival month.
3. Analyze ADR and estimated booking value.
4. Analyze payment methods, payment status, refunds and payment-risk flags.
5. Create summary tables and visualizations.

## Important Note
All customer, booking and financial values are synthetic and intended only for portfolio/educational analysis.
