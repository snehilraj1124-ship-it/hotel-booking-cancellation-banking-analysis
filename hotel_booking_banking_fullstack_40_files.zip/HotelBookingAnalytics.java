import java.io.*;
import java.util.*;

public class HotelBookingAnalytics {
    public static void main(String[] args) throws Exception {
        String file = "hotel_booking_cancellation_dataset.csv";
        BufferedReader br = new BufferedReader(new FileReader(file));
        String header = br.readLine();

        int rows = 0;
        int cancelled = 0;
        String line;

        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",", -1);
            if (parts.length > 0) {
                rows++;
                // Cancelled is the second-last field in the generated dataset.
                for (int i = 0; i < parts.length; i++) {
                    if ("Cancelled".equals(parts[i].trim())) {
                        if (i + 1 < parts.length && "1".equals(parts[i + 1].trim())) {
                            cancelled++;
                        }
                        break;
                    }
                }
            }
        }
        br.close();

        double rate = rows == 0 ? 0 : (cancelled * 100.0 / rows);
        System.out.println("Hotel Booking Analytics");
        System.out.println("Rows: " + rows);
        System.out.printf("Cancellation rate: %.2f%%%n", rate);
    }
}
