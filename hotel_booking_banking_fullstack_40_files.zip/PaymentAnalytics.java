import java.io.*;
import java.util.*;

public class PaymentAnalytics {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(
            new FileReader("hotel_booking_cancellation_dataset.csv")
        );

        String header = br.readLine();
        String[] columns = header.split(",", -1);
        int paymentMethod = -1, transaction = -1, refund = -1;

        for (int i = 0; i < columns.length; i++) {
            if (columns[i].equals("Payment_Method")) paymentMethod = i;
            if (columns[i].equals("Transaction_Amount")) transaction = i;
            if (columns[i].equals("Refund_Amount")) refund = i;
        }

        Map<String, Double> totals = new TreeMap<>();
        Map<String, Double> refunds = new TreeMap<>();

        String line;
        while ((line = br.readLine()) != null) {
            String[] p = line.split(",", -1);
            String method = p[paymentMethod];
            double value = Double.parseDouble(p[transaction]);
            double refundValue = Double.parseDouble(p[refund]);

            totals.put(method, totals.getOrDefault(method, 0.0) + value);
            refunds.put(method, refunds.getOrDefault(method, 0.0) + refundValue);
        }
        br.close();

        for (String method : totals.keySet()) {
            System.out.printf(
                "%s -> transactions: %.2f, refunds: %.2f%n",
                method, totals.get(method), refunds.get(method)
            );
        }
    }
}
