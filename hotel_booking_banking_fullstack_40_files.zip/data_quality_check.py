import pandas as pd

df = pd.read_csv("hotel_booking_cancellation_dataset.csv")

print("Rows:", len(df))
print("Columns:", len(df.columns))
print("\nMissing values:")
print(df.isna().sum())

print("\nDuplicate Booking IDs:", df["Booking_ID"].duplicated().sum())
print("Negative transaction values:", (df["Transaction_Amount"] < 0).sum())
print("Negative refund values:", (df["Refund_Amount"] < 0).sum())
